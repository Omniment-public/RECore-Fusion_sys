from pyrecore.core.crc import get_crc8


def test_get_crc8():
    assert 0x12 == get_crc8(b'\xBE\xEF\xC7\xA9\x9F')
