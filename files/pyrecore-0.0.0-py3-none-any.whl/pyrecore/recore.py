﻿# RECore-PyRECore --- A Python library for control of RECore
#
# Copyright (c) 2021 Omniment, Inc.
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.


import struct
from typing import Union, Optional
from serial import Serial

from .core.packet import Request
from .core.datalink import DataLink, SerialDataLink
from .core.remote_protocol import RemoteProtocol
from .gpio import PinDir
from .motor import MotorUnit, MotorType, BrakeMode
from .imu import AccScale, AccRate, AngularRateScale, AngularRate
from .auto_interruptor import AutoInterruptor
from .core.interruptible import Interruptible

__all__ = [
    'RECore'
]


class RECore(Interruptible):
    """Omniment PyRECore Remote Protocol

    The official implementation of PyRECore Remote Protocol"""

    I2C_MASTER_ADDRESS = 0x01

    def __init__(self, arg: Optional[Union[RemoteProtocol, DataLink]] = None):
        if arg is None:
            link = SerialDataLink(Serial('/dev/ttyS0', 115200))
            self._protocol = RemoteProtocol(link, 'little')
        elif isinstance(arg, RemoteProtocol):
            self._protocol = arg
        elif isinstance(arg, DataLink):
            self._protocol = RemoteProtocol(arg, 'little')
        else:
            raise TypeError(
                'RECore only accepts None, DataLink or RemoteProtocol')

        AutoInterruptor().register(self)

    def close(self):
        AutoInterruptor().unregister(self)
        self._protocol.close()

    def pinMode(self, pin: int, mode: PinDir):

        data = struct.pack('<BB', pin, mode)
        self._protocol.write(Request(0x0001, data))
        self._protocol.read()

    def digitalRead(self, pin: int) -> int:

        data = struct.pack('<B', pin)
        self._protocol.write(Request(0x0002, data))
        resp = self._protocol.read()
        ret = struct.unpack('<B', resp.payload)[0]
        return ret

    def digitalWrite(self, pin: int, value: int):

        data = struct.pack('<BB', pin, value)
        self._protocol.write(Request(0x0003, data))
        self._protocol.read()

    def analogRead(self, pin: int) -> int:

        data = struct.pack('<B', pin)
        self._protocol.write(Request(0x0004, data))
        resp = self._protocol.read()
        ret = struct.unpack('<H', resp.payload)[0]
        return ret

    def analogWrite(self, pin: int, value: int):
        if value < 0 or value > 1023:
            raise ValueError('analogWrite: "value" out of range')

        data = struct.pack('<BxH', pin, value)
        self._protocol.write(Request(0x0005, data))
        self._protocol.read()

    def getBatteryVoltage(self,) -> float:
        self._protocol.write(Request(0x0006, b''))
        resp = self._protocol.read()
        ret = struct.unpack('<f', resp.payload)[0]
        return ret

    def getMcuTemp(self,) -> int:
        self._protocol.write(Request(0x0007, b''))
        resp = self._protocol.read()
        ret = struct.unpack('<b', resp.payload)[0]
        return ret

    def wireBegin(self, address: int = I2C_MASTER_ADDRESS):

        data = struct.pack('<B', address)
        self._protocol.write(Request(0x0008, data))
        self._protocol.read()

    def wireRequestFrom(self, address: int, quantity: int) -> int:

        data = struct.pack('<BB', address, quantity)
        self._protocol.write(Request(0x0009, data))
        resp = self._protocol.read()
        ret = struct.unpack('<B', resp.payload)[0]
        return ret

    def wireBeginTransmission(self, address: int = I2C_MASTER_ADDRESS):

        data = struct.pack('<B', address)
        self._protocol.write(Request(0x000a, data))
        self._protocol.read()

    def wireEndTransmission(self,) -> int:
        self._protocol.write(Request(0x000b, b''))
        resp = self._protocol.read()
        ret = struct.unpack('<B', resp.payload)[0]
        return ret

    def wireWrite(self, value: int):
        if value < 0 or value > 255:
            raise ValueError('wireWrite: "value" out of range')

        data = struct.pack('<B', value)
        self._protocol.write(Request(0x000c, data))
        self._protocol.read()

    def wireAvailable(self,) -> int:
        self._protocol.write(Request(0x000d, b''))
        resp = self._protocol.read()
        ret = struct.unpack('<B', resp.payload)[0]
        return ret

    def wireRead(self,) -> int:
        self._protocol.write(Request(0x000e, b''))
        resp = self._protocol.read()
        ret = struct.unpack('<B', resp.payload)[0]
        return ret

    def setMotorType(
            self,
            driver_unit: MotorUnit,
            motor_type: MotorType,
            stm_steps: int = 200):
        if stm_steps < 0:
            raise ValueError('setMotorType: "stm_steps" out of range')

        data = struct.pack('<BBH', driver_unit, motor_type, stm_steps)
        self._protocol.write(Request(0x000f, data))
        self._protocol.read()

    def setMotorCurrent(self, motor_current: int):

        data = struct.pack('<H', motor_current)
        self._protocol.write(Request(0x0010, data))
        self._protocol.read()

    def setBrakeMode(self, motor_num: int, brake_mode: BrakeMode):
        if motor_num < 0 or motor_num > 3:
            raise ValueError('setBrakeMode: "motor_num" out of range')

        data = struct.pack('<BB', motor_num, brake_mode)
        self._protocol.write(Request(0x0011, data))
        self._protocol.read()

    def setMotorSpeed(self, motor_num: int, speed: float):
        if motor_num < 0 or motor_num > 3:
            raise ValueError('setMotorSpeed: "motor_num" out of range')

        data = struct.pack('<Bxxxf', motor_num, speed)
        self._protocol.write(Request(0x0012, data))
        self._protocol.read()

    def setDrivePwm(self, motor_num: int, drive_pwm: int):
        if motor_num < 0 or motor_num > 3:
            raise ValueError('setDrivePwm: "motor_num" out of range')

        data = struct.pack('<Bxh', motor_num, drive_pwm)
        self._protocol.write(Request(0x0013, data))
        self._protocol.read()

    def setSteppingSpeed(self, driver_unit: MotorUnit, speed: int, dir: bool):
        if driver_unit < 0 or driver_unit > 1:
            raise ValueError('setSteppingSpeed: "driver_unit" out of range')

        data = struct.pack('<BxHB', driver_unit, speed, dir)
        self._protocol.write(Request(0x0014, data))
        self._protocol.read()

    def setSteppingSteps(
            self,
            driver_unit: MotorUnit,
            speed: int,
            step_count: int):
        if driver_unit < 0 or driver_unit > 1:
            raise ValueError('setSteppingSteps: "driver_unit" out of range')

        data = struct.pack('<BxHi', driver_unit, speed, step_count)
        self._protocol.write(Request(0x0015, data))
        self._protocol.read()

    def getMotorFault(self,) -> bool:
        self._protocol.write(Request(0x0016, b''))
        resp = self._protocol.read()
        ret = struct.unpack('<B', resp.payload)[0]
        return bool(ret)

    def getRawAccX(self,) -> int:
        self._protocol.write(Request(0x0017, b''))
        resp = self._protocol.read()
        ret = struct.unpack('<H', resp.payload)[0]
        return ret

    def getRawAccY(self,) -> int:
        self._protocol.write(Request(0x0018, b''))
        resp = self._protocol.read()
        ret = struct.unpack('<H', resp.payload)[0]
        return ret

    def getRawAccZ(self,) -> int:
        self._protocol.write(Request(0x0019, b''))
        resp = self._protocol.read()
        ret = struct.unpack('<H', resp.payload)[0]
        return ret

    def getAccX(self,) -> float:
        self._protocol.write(Request(0x001a, b''))
        resp = self._protocol.read()
        ret = struct.unpack('<f', resp.payload)[0]
        return ret

    def getAccY(self,) -> float:
        self._protocol.write(Request(0x001b, b''))
        resp = self._protocol.read()
        ret = struct.unpack('<f', resp.payload)[0]
        return ret

    def getAccZ(self,) -> float:
        self._protocol.write(Request(0x001c, b''))
        resp = self._protocol.read()
        ret = struct.unpack('<f', resp.payload)[0]
        return ret

    def getRawAngularRateX(self,) -> int:
        self._protocol.write(Request(0x001d, b''))
        resp = self._protocol.read()
        ret = struct.unpack('<H', resp.payload)[0]
        return ret

    def getRawAngularRateY(self,) -> int:
        self._protocol.write(Request(0x001e, b''))
        resp = self._protocol.read()
        ret = struct.unpack('<H', resp.payload)[0]
        return ret

    def getRawAngularRateZ(self,) -> int:
        self._protocol.write(Request(0x001f, b''))
        resp = self._protocol.read()
        ret = struct.unpack('<H', resp.payload)[0]
        return ret

    def getAngularRateX(self,) -> float:
        self._protocol.write(Request(0x0020, b''))
        resp = self._protocol.read()
        ret = struct.unpack('<f', resp.payload)[0]
        return ret

    def getAngularRateY(self,) -> float:
        self._protocol.write(Request(0x0021, b''))
        resp = self._protocol.read()
        ret = struct.unpack('<f', resp.payload)[0]
        return ret

    def getAngularRateZ(self,) -> float:
        self._protocol.write(Request(0x0022, b''))
        resp = self._protocol.read()
        ret = struct.unpack('<f', resp.payload)[0]
        return ret

    def getAccScale(self,) -> int:
        self._protocol.write(Request(0x0023, b''))
        resp = self._protocol.read()
        ret = struct.unpack('<B', resp.payload)[0]
        return ret

    def getAccScaleConstant(self,) -> float:
        self._protocol.write(Request(0x0024, b''))
        resp = self._protocol.read()
        ret = struct.unpack('<f', resp.payload)[0]
        return ret

    def getAngularRateScale(self,) -> int:
        self._protocol.write(Request(0x0025, b''))
        resp = self._protocol.read()
        ret = struct.unpack('<H', resp.payload)[0]
        return ret

    def getAngularRateScaleConstant(self,) -> float:
        self._protocol.write(Request(0x0026, b''))
        resp = self._protocol.read()
        ret = struct.unpack('<f', resp.payload)[0]
        return ret

    def setAccDataRate(self, value: AccRate):

        data = struct.pack('<B', value)
        self._protocol.write(Request(0x0027, data))
        self._protocol.read()

    def setAccScale(self, value: AccScale):

        data = struct.pack('<B', value)
        self._protocol.write(Request(0x0028, data))
        self._protocol.read()

    def setAccLpfBandwith(self, value: int):

        data = struct.pack('<B', value)
        self._protocol.write(Request(0x0029, data))
        self._protocol.read()

    def setAngularRateDataRate(self, value: AngularRate):

        data = struct.pack('<B', value)
        self._protocol.write(Request(0x002a, data))
        self._protocol.read()

    def setAngularRateScale(self, value: AngularRateScale):

        data = struct.pack('<B', value)
        self._protocol.write(Request(0x002b, data))
        self._protocol.read()

    def interrupt(self,):
        self._protocol.write(Request(0x002c, b''))
        self._protocol.read()
