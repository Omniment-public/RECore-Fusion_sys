#!/usr/bin/env python3
# RECore-PyRECore --- A Python library for control of RECore
#
# Copyright (c) 2021 Omniment, Inc.
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from enum import IntEnum

__all__ = [
    'AccScale',
    'AccRate',
    'AngularRateScale',
    'AngularRate'
]


class AccScale(IntEnum):
    ACC_2G = 0x00
    ACC_4G = 0x02
    ACC_8G = 0x03
    ACC_16G = 0x01


class AccRate(IntEnum):
    ACC_RATE_DOWN = 0x00
    ACC_RATE_12_5_HZ = 0x01
    ACC_RATE_26_HZ = 0x02
    ACC_RATE_52_HZ = 0x03
    ACC_RATE_104_HZ = 0x04
    ACC_RATE_208_HZ = 0x05
    ACC_RATE_416_HZ = 0x06
    ACC_RATE_833_HZ = 0x07
    ACC_RATE_1660_HZ = 0x08
    ACC_RATE_3330_HZ = 0x09
    ACC_RATE_6660_HZ = 0x0A


class AngularRateScale(IntEnum):
    A_RATE_250DPS = 0x00
    A_RATE_500DPS = 0x01
    A_RATE_1000DPS = 0x02
    A_RATE_2000DPS = 0x03
    A_RATE_125DPS = 0x04


class AngularRate(IntEnum):
    A_RATE_DOWN = 0x00
    A_RATE_12_5_HZ = 0x01
    A_RATE_26_HZ = 0x02
    A_RATE_52_HZ = 0x03
    A_RATE_104_HZ = 0x04
    A_RATE_208_HZ = 0x05
    A_RATE_416_HZ = 0x06
    A_RATE_833_HZ = 0x07
    A_RATE_1660_HZ = 0x08
